"use strict";
// Richtiges Passwort festlegen
const correctPassword = "213sk";
// DOM-Elemente abrufen
const passwordInput = document.getElementById("passwordInput");
const submitButton = document.getElementById("submitPassword");
const errorText = document.getElementById("error");
const passwordPrompt = document.getElementById("passwordPrompt");
const mainContent = document.getElementById("mainContent");
// Funktion zur Passwortüberprüfung
function checkPassword() {
    const enteredPassword = passwordInput.value;
    console.log("Eingegebenes Passwort:", enteredPassword); // Überprüfe, ob das Passwort eingegeben wurde
    // Überprüfen, ob das eingegebene Passwort korrekt ist
    if (enteredPassword === correctPassword) {
        console.log("Passwort korrekt!"); // Log für korrektes Passwort
        passwordPrompt.classList.add("hidden"); // Passwortabfrage ausblenden
        mainContent.classList.remove("hidden"); // Hauptinhalt anzeigen
        errorText.classList.add("hidden"); // Fehlermeldung ausblenden
    }
    else {
        console.log("Passwort falsch!"); // Log für falsches Passwort
        errorText.classList.remove("hidden"); // Fehlermeldung anzeigen
    }
}
// Event-Listener für den Button hinzufügen
submitButton.addEventListener("click", checkPassword);
// Optional: Passwort auch per Enter-Taste bestätigen
passwordInput.addEventListener("keyup", (event) => {
    if (event.key === "Enter") {
        checkPassword();
    }
});
// Modal- und Schließen-Button-Elemente auswählen
const modal = document.getElementById("myModal");
const image = document.querySelector(".clickable-image");
const closeButton = document.querySelector(".close");
// Überprüfen, ob die Elemente existieren, bevor die Event-Listener hinzugefügt werden
if (modal && image && closeButton) {
    // Bild anklicken, um das Modal zu öffnen
    image.onclick = function () {
        modal.style.display = "block";
    };
    // Modal durch Klick auf das Schließen-Symbol schließen
    closeButton.onclick = function () {
        modal.style.display = "none";
    };
    // Modal schließen, wenn außerhalb des Inhalts geklickt wird
    window.onclick = function (event) {
        if (event.target === modal) {
            modal.style.display = "none";
        }
    };
}
